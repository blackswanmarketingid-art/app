package com.callsync.dialer.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first

private val Context.dataStore by preferencesDataStore(name = "callsync_session")

/**
 * Holds which rep is logged in on this device. In this skeleton, repId is
 * just a string the rep types in (matching the seeded rep IDs in the backend,
 * e.g. "rep_aisha") — swap setRepId's caller for the real Zoho-OAuth-derived
 * identity once that flow is wired up (see MainActivity).
 */
object SessionStore {
    private val REP_ID_KEY = stringPreferencesKey("rep_id")

    suspend fun setRepId(context: Context, repId: String) {
        context.dataStore.edit { it[REP_ID_KEY] = repId }
    }

    suspend fun getRepId(context: Context): String? {
        return context.dataStore.data.first()[REP_ID_KEY]
    }
}
