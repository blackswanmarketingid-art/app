package com.callsync.dialer.recording

import android.media.MediaRecorder
import android.os.Build
import android.util.Log
import java.io.File

/**
 * Wraps MediaRecorder to capture call audio.
 *
 * IMPORTANT — read before assuming this "just works" on any device:
 *
 * Being the default dialer exempts this app from Google Play's Accessibility-API
 * call-recording restriction, but it does NOT guarantee the audio source below
 * is actually available. Since Android 10, access to VOICE_CALL / VOICE_DOWNLINK
 * /VOICE_UPLINK audio sources is additionally gated by the device manufacturer —
 * many OEMs (notably stock Android / Pixel) block or silently mute these sources
 * at the HAL level regardless of app permissions or dialer status. Recording tends
 * to actually work on: Samsung (in supported regions), Xiaomi/HyperOS, OnePlus,
 * and other Chinese OEMs with permissive audio HALs — and tends to NOT work on
 * Pixel/stock AOSP builds. Test on your actual target devices before assuming
 * this pipeline is functional at all — there is no universal API-level fix,
 * it is genuinely hardware/firmware dependent.
 *
 * If VOICE_CALL / VOICE_DOWNLINK both fail on your fleet's actual devices, the
 * fallback used by most commercial call-recording apps is speakerphone mode +
 * MediaRecorder.AudioSource.MIC — worse audio quality, but works everywhere,
 * since it just captures ambient mic audio while the call is on speaker.
 */
class CallRecorder(private val outputDir: File) {

    private var recorder: MediaRecorder? = null
    var outputFile: File? = null
        private set

    fun start(callId: String): Boolean {
        val file = File(outputDir, "call_${callId}_${System.currentTimeMillis()}.m4a")
        outputFile = file

        return try {
            val mr = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                MediaRecorder(null)
            } else {
                @Suppress("DEPRECATION")
                MediaRecorder()
            }

            // Try VOICE_CALL first (captures both sides where the OEM allows it).
            // See class doc above — this is the line most likely to fail per-device.
            mr.setAudioSource(MediaRecorder.AudioSource.VOICE_CALL)
            mr.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            mr.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            mr.setAudioEncodingBitRate(128000)
            mr.setAudioSamplingRate(44100)
            mr.setOutputFile(file.absolutePath)
            mr.prepare()
            mr.start()

            recorder = mr
            Log.i("CallRecorder", "Recording started -> ${file.absolutePath}")
            true
        } catch (e: Exception) {
            // This is the expected failure path on devices that block VOICE_CALL.
            // A production build should fall back to AudioSource.MIC + a prompt
            // asking the rep to switch to speakerphone — not silently do nothing.
            Log.e("CallRecorder", "VOICE_CALL recording unavailable on this device", e)
            recorder = null
            false
        }
    }

    fun stop(): File? {
        return try {
            recorder?.apply {
                stop()
                release()
            }
            recorder = null
            outputFile
        } catch (e: Exception) {
            Log.e("CallRecorder", "Error stopping recorder", e)
            null
        }
    }
}
