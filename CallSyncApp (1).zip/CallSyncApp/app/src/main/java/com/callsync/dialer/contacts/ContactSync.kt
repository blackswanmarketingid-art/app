package com.callsync.dialer.contacts

import android.content.Context
import android.provider.ContactsContract
import android.util.Log
import com.callsync.dialer.network.ApiClient

data class DeviceContact(val name: String, val number: String)

/**
 * Reads the phone's contact list and checks each number against Zoho leads,
 * per the "Login and sync" step in the workflow. Kept simple and synchronous
 * here — wrap this in a WorkManager job for a real background sync that
 * survives app restarts and doesn't block the UI thread.
 */
object ContactSync {

    fun readDeviceContacts(context: Context): List<DeviceContact> {
        val contacts = mutableListOf<DeviceContact>()
        val cursor = context.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ),
            null, null, null
        )

        cursor?.use {
            val nameIdx = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
            val numberIdx = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
            while (it.moveToNext()) {
                val name = it.getString(nameIdx) ?: continue
                val number = it.getString(numberIdx) ?: continue
                contacts.add(DeviceContact(name, number.replace(Regex("[\\s()-]"), "")))
            }
        }
        return contacts
    }

    /** Cross-references device contacts against Zoho leads via the backend. */
    suspend fun matchAgainstZoho(contacts: List<DeviceContact>): Int {
        var matches = 0
        for (contact in contacts) {
            try {
                val result = ApiClient.api.lookupLead(contact.number)
                if (result.body()?.get("lead") != null) matches++
            } catch (e: Exception) {
                Log.w("ContactSync", "Lookup failed for ${contact.number}", e)
            }
        }
        return matches
    }
}
