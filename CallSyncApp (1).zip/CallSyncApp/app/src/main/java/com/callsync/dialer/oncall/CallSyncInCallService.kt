package com.callsync.dialer.oncall

import android.telecom.Call
import android.telecom.InCallService
import android.util.Log
import com.callsync.dialer.data.SessionStore
import com.callsync.dialer.network.ApiClient
import com.callsync.dialer.network.CreateCallRequest
import com.callsync.dialer.network.PatchCallRequest
import com.callsync.dialer.recording.CallRecorder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody

/**
 * Registered in AndroidManifest.xml as the app's InCallService. Once this app
 * is set as the default dialer, Android routes every call's lifecycle through
 * here — this is the actual trigger point for the whole pipeline described in
 * the workflow diagram: call connects -> match against Zoho -> record if
 * matched -> upload + log on Zoho's timeline when the call ends.
 */
class CallSyncInCallService : InCallService() {

    private val scope = CoroutineScope(Dispatchers.IO)
    private var activeCallId: String? = null
    private var recorder: CallRecorder? = null
    private var callStartMillis: Long = 0L

    override fun onCallAdded(call: Call) {
        super.onCallAdded(call)
        call.registerCallback(callCallback)
        handleCallStateChanged(call, call.state)
    }

    override fun onCallRemoved(call: Call) {
        super.onCallRemoved(call)
        call.unregisterCallback(callCallback)
    }

    private val callCallback = object : Call.Callback() {
        override fun onStateChanged(call: Call, state: Int) {
            handleCallStateChanged(call, state)
        }
    }

    private fun handleCallStateChanged(call: Call, state: Int) {
        when (state) {
            Call.STATE_ACTIVE -> onCallConnected(call)
            Call.STATE_DISCONNECTED -> onCallEnded(call)
            else -> Unit // ringing, dialing, holding — nothing to do yet
        }
    }

    // ---- Call connected: create the call record, then check Zoho ----------

    private fun onCallConnected(call: Call) {
        if (activeCallId != null) return // already handling this call

        val number = call.details.handle?.schemeSpecificPart ?: "unknown"
        val direction = if (call.details.callDirection == Call.Details.DIRECTION_INCOMING) {
            "inbound"
        } else {
            "outbound"
        }

        callStartMillis = System.currentTimeMillis()

        scope.launch {
            try {
                val repId = SessionStore.getRepId(applicationContext) ?: run {
                    Log.w("CallSyncInCall", "No logged-in rep — skipping call logging entirely")
                    return@launch
                }

                val created = ApiClient.api.createCall(CreateCallRequest(repId, number, direction))
                val callRecord = created.body() ?: return@launch
                activeCallId = callRecord.id

                val matchResult = ApiClient.api.matchCall(callRecord.id).body()
                if (matchResult?.matched == true) {
                    Log.i("CallSyncInCall", "Matched Zoho lead: ${matchResult.lead?.name} — starting recording")
                    recorder = CallRecorder(applicationContext.cacheDir).also { it.start(callRecord.id) }
                } else {
                    Log.i("CallSyncInCall", "No Zoho match for $number — not recording")
                }
            } catch (e: Exception) {
                Log.e("CallSyncInCall", "Failed to log call start to backend", e)
            }
        }
    }

    // ---- Call ended: stop recording, upload, patch duration, sync to Zoho -

    private fun onCallEnded(call: Call) {
        val callId = activeCallId ?: return
        val durationSec = ((System.currentTimeMillis() - callStartMillis) / 1000).toInt()
        val audioFile = recorder?.stop()

        scope.launch {
            try {
                ApiClient.api.endCall(callId, PatchCallRequest(status = "ended", durationSec = durationSec))

                if (audioFile != null && audioFile.exists()) {
                    val body = audioFile.asRequestBody("audio/mp4".toMediaTypeOrNull())
                    val part = MultipartBody.Part.createFormData("audio", audioFile.name, body)
                    ApiClient.api.uploadRecording(callId, part)
                    audioFile.delete() // uploaded — don't keep call audio on-device longer than needed
                }

                ApiClient.api.syncToZoho(callId)
                Log.i("CallSyncInCall", "Call $callId logged, uploaded, and synced to Zoho")
            } catch (e: Exception) {
                Log.e("CallSyncInCall", "Failed to finalize call $callId", e)
                // Production version: queue this for retry (e.g. WorkManager) instead
                // of losing the recording/log on a transient network failure.
            }
        }

        activeCallId = null
        recorder = null
    }
}
