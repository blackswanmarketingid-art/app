package com.callsync.dialer.network

import okhttp3.MultipartBody
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Multipart
import retrofit2.http.PATCH
import retrofit2.http.POST
import retrofit2.http.Part
import retrofit2.http.Path
import retrofit2.http.Query

// ---- Request/response bodies — mirror the backend's JSON shapes exactly ----

data class CreateCallRequest(
    val repId: String,
    val number: String,
    val direction: String // "inbound" | "outbound"
)

data class PatchCallRequest(
    val status: String, // "ended"
    val durationSec: Int
)

data class CallRecord(
    val id: String,
    val repId: String,
    val number: String,
    val direction: String?,
    val startedAt: String,
    val endedAt: String?,
    val durationSec: Int?,
    val status: String,
    val matched: Boolean,
    val leadName: String?,
    val zohoId: String?,
    val zohoSynced: Boolean,
    val recordingUrl: String?
)

data class MatchResponse(
    val matched: Boolean,
    val lead: Lead?,
    val call: CallRecord
)

data class Lead(
    val number: String,
    val name: String,
    val zohoId: String,
    val stage: String
)

data class RecordingUploadResponse(
    val recordingUrl: String,
    val call: CallRecord
)

// ---- The API surface the app actually calls ----
// This maps 1:1 onto routes/calls.js and routes/zoho.js in the backend.

interface CallSyncApi {

    @POST("api/calls")
    suspend fun createCall(@Body body: CreateCallRequest): Response<CallRecord>

    @POST("api/calls/{id}/match")
    suspend fun matchCall(@Path("id") callId: String): Response<MatchResponse>

    @PATCH("api/calls/{id}")
    suspend fun endCall(@Path("id") callId: String, @Body body: PatchCallRequest): Response<CallRecord>

    @Multipart
    @POST("api/calls/{id}/recording")
    suspend fun uploadRecording(
        @Path("id") callId: String,
        @Part audio: MultipartBody.Part
    ): Response<RecordingUploadResponse>

    @POST("api/zoho/sync/{callId}")
    suspend fun syncToZoho(@Path("callId") callId: String): Response<Unit>

    @GET("api/zoho/leads/lookup")
    suspend fun lookupLead(@Query("number") number: String): Response<Map<String, Lead?>>
}
