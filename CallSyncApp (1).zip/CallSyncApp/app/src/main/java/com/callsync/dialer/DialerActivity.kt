package com.callsync.dialer

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

/**
 * STUB. Android requires a default dialer app to handle ACTION_DIAL /
 * ACTION_CALL — this is meant to be the actual dialpad + contact picker
 * screen a rep uses to place calls. Not built here: this skeleton focuses
 * on the call-detection/recording/logging pipeline (CallSyncInCallService),
 * not on replacing the phone's dialer UI end to end.
 *
 * Until this is built out, CallSync cannot actually function as a complete
 * default dialer app on a device — it will register the role, but a rep
 * has no way to place a call through it. Options, roughly in order of
 * effort:
 *   1. Build a minimal dialpad + call button here (a few hours of work —
 *      android.telecom.TelecomManager.placeCall() is the API to use).
 *   2. Keep the rep's original dialer app for dialing, and set THIS app as
 *      default dialer anyway — Android still routes call state through
 *      CallSyncInCallService regardless of which UI the rep dialed from,
 *      as long as this app holds the default dialer role. This is usually
 *      the pragmatic choice: reps keep a UI they're used to, this app
 *      quietly does the logging/recording in the background.
 */
class DialerActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(TextView(this).apply {
            text = "CallSync dialer — not yet built. See DialerActivity.kt for next steps."
            setPadding(48, 96, 48, 48)
        })
    }
}
