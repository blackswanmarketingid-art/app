package com.callsync.dialer

import android.app.role.RoleManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.lifecycle.lifecycleScope
import com.callsync.dialer.contacts.ContactSync
import com.callsync.dialer.data.SessionStore
import com.callsync.dialer.databinding.ActivityMainBinding
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val requiredPermissions = arrayOf(
        android.Manifest.permission.READ_PHONE_STATE,
        android.Manifest.permission.READ_CALL_LOG,
        android.Manifest.permission.RECORD_AUDIO,
        android.Manifest.permission.READ_CONTACTS,
        android.Manifest.permission.CALL_PHONE,
        android.Manifest.permission.ANSWER_PHONE_CALLS,
    )

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val allGranted = results.values.all { it }
        if (allGranted) {
            promptDefaultDialerRole()
        } else {
            Toast.makeText(this, "All permissions are required for call logging to work", Toast.LENGTH_LONG).show()
        }
    }

    private val dialerRoleLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            Toast.makeText(this, "CallSync is now the default dialer", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Default dialer role was not granted — recording won't work without it", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        handleIncomingOAuthRedirect(intent)

        binding.btnSaveRepId.setOnClickListener {
            val repId = binding.repIdInput.text?.toString()?.trim()
            if (repId.isNullOrEmpty()) {
                Toast.makeText(this, "Enter a rep ID (e.g. rep_aisha)", Toast.LENGTH_SHORT).show()
            } else {
                lifecycleScope.launch {
                    SessionStore.setRepId(applicationContext, repId)
                    Toast.makeText(this@MainActivity, "Logged in as $repId", Toast.LENGTH_SHORT).show()
                }
            }
        }

        binding.btnRequestPermissions.setOnClickListener { requestAllPermissions() }
        binding.btnSyncContacts.setOnClickListener { syncContacts() }

        binding.btnZohoLogin.setOnClickListener {
            // Real flow: open Zoho's OAuth URL in a Custom Tab, e.g.
            // https://accounts.zoho.com/oauth/v2/auth?client_id=...&scope=ZohoCRM.modules.ALL
            //   &redirect_uri=callsync://oauth&response_type=code&access_type=offline
            // Zoho redirects back to callsync://oauth?code=..., caught in
            // handleIncomingOAuthRedirect() below, which then POSTs the code
            // to the backend's /api/zoho/oauth/callback (see routes/zoho.js).
            Toast.makeText(this, "Wire this button to your Zoho OAuth URL — see comment in MainActivity.kt", Toast.LENGTH_LONG).show()
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIncomingOAuthRedirect(intent)
    }

    private fun handleIncomingOAuthRedirect(intent: Intent?) {
        val uri: Uri = intent?.data ?: return
        if (uri.scheme == "callsync" && uri.host == "oauth") {
            val code = uri.getQueryParameter("code")
            if (code != null) {
                // TODO: POST this code + the logged-in repId to your backend's
                // /api/zoho/oauth/callback so it can complete the token exchange.
                Toast.makeText(this, "Got Zoho auth code — send it to your backend here", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun requestAllPermissions() {
        val missing = requiredPermissions.filter {
            ActivityCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) {
            promptDefaultDialerRole()
        } else {
            permissionLauncher.launch(missing.toTypedArray())
        }
    }

    private fun promptDefaultDialerRole() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val roleManager = getSystemService(RoleManager::class.java)
            if (roleManager.isRoleAvailable(RoleManager.ROLE_DIALER) &&
                !roleManager.isRoleHeld(RoleManager.ROLE_DIALER)
            ) {
                dialerRoleLauncher.launch(roleManager.createRequestRoleIntent(RoleManager.ROLE_DIALER))
            }
        } else {
            // Pre-Android 10 fallback: TelecomManager.ACTION_CHANGE_DEFAULT_DIALER
            Toast.makeText(this, "Default dialer role requires Android 10+", Toast.LENGTH_LONG).show()
        }
    }

    private fun syncContacts() {
        lifecycleScope.launch {
            val contacts = ContactSync.readDeviceContacts(applicationContext)
            Toast.makeText(this@MainActivity, "Read ${contacts.size} contacts, matching against Zoho...", Toast.LENGTH_SHORT).show()
            val matches = ContactSync.matchAgainstZoho(contacts)
            Toast.makeText(this@MainActivity, "$matches of ${contacts.size} contacts matched a Zoho lead", Toast.LENGTH_LONG).show()
        }
    }
}
